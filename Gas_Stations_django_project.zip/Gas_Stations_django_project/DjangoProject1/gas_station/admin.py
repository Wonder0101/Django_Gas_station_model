from django.contrib import admin

# Register your models here.


# Register your models here.
from django.contrib import admin
from .models import GasStation

@admin.register(GasStation)
class GasStationAdmin(admin.ModelAdmin):
    list_display = ('name', 'address', 'phone', 'hours', 'date', 'google_maps_url')
    search_fields = ('name', 'address')
    list_filter = ('date',)