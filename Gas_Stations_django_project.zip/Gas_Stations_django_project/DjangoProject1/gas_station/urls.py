from django.urls import path
from gas_station import views

urlpatterns = [


    path('gas_stations/', views.gas_stations, name='gas_stations'),
]