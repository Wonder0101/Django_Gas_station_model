from django.db import models

# Create your models here.

class Worldcities(models.Model):
    city = models.TextField(blank=True, null=True)
    lat = models.TextField(blank=True, null=True)  # This field type is a guess.
    lng = models.TextField(blank=True, null=True)  # This field type is a guess.
    country = models.TextField(blank=True, null=True)
    id = models.TextField(blank=True, primary_key=True)

    class Meta:
        managed = False
        db_table = 'worldcities'


class GasStation(models.Model):
    name = models.CharField(max_length=255)
    address = models.CharField(max_length=255)
    phone = models.CharField(max_length=15)
    hours = models.CharField(max_length=50)
    regular_price = models.DecimalField(max_digits=5, decimal_places=2)
    premium_price = models.DecimalField(max_digits=5, decimal_places=2)
    diesel_price = models.DecimalField(max_digits=5, decimal_places=2)
    date = models.DateField()
    google_maps_url = models.URLField(max_length=500, blank=True, null=True)  # New field for Google Maps link

    def __str__(self):
        return self.name